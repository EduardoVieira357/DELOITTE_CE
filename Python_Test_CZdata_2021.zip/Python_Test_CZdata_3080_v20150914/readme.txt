
 There is no previous knowledge of Python language needed for this test.
 There are no time requirements/limitations for finishing the test.
 Any version of python http://python.org/ can be used.

 Task description:

    create python script that transforms 
    input data in folder 'input' into 
    files output_1, output_2, output_3
    
 Task limitations of python script:

    a) must have less than 30 rows
    b) every row can have maximum 80 characters
    c) can import only following libraries: glob, re
    d) must run without any error messages
    e) can not contain any tab characters (x09); use spaces
